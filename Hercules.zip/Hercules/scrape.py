import os
import sys
import httpx
from colorama import Fore, init

# Initialize colorama for colored output
init(autoreset=True)

# Define color variables for styling output
fr = Fore.RED
fg = Fore.GREEN
fy = Fore.YELLOW
fw = Fore.WHITE

# List of proxy URLs
proxy_list = [
    'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
    'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt',
    'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt',
    'https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt',
    'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt',
    'https://api.openproxylist.xyz/http.txt',
    'https://api.proxyscrape.com/v2/?request=displayproxies',
    'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
    'https://www.proxydocker.com/en/proxylist/download?email=noshare&country=all&city=all&port=all&type=all&anonymity=all&state=all&need=all',
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous',
    'http://worm.rip/http.txt',
    'https://proxyspace.pro/http.txt',
    'https://multiproxy.org/txt_all/proxy.txt',
    'https://proxy-spider.com/api/proxies.example.txt',
]

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def download_proxies(file, proxy_list):
    # Check if the proxy file already exists
    if os.path.isfile(file):
        clear_screen()
        os.remove(file)
        print(f"{fr}File {file} already exists!\n{fy}Downloading a new {file}!\n")
    else:
        clear_screen()

    # Download proxies and save to file
    with open(file, 'a') as data:
        for proxy_url in proxy_list:
            data.write(httpx.get(proxy_url).text)
            print(f" -| Fetching {fg}{proxy_url}")

def count_proxies(file):
    # Count the total number of proxies in the file
    with open(file, 'r') as proxy_file:
        total = sum(1 for line in proxy_file)
    print(f"\n{fw}( {fy}{total} {fw}) {fg}Proxies successfully downloaded.")

if __name__ == "__main__":
    proxy_file = "proxy.txt"
    
    try:
        download_proxies(proxy_file, proxy_list)
        count_proxies(proxy_file)
    except Exception as e:
        print(f"{fr}Error occurred: {e}")
        sys.exit(1)