import os
import sys

# Installing required packages
os.system('pkg install openjdk-17')
os.system('pkg install nodejs-lts')
os.system('pkg install qb64')

# Installing NodeJS modules
os.system('npm install url')
os.system('npm install https')
os.system('npm install net')
os.system('npm install crypto')
os.system('npm install axios')
os.system('npm install request')
os.system('npm install header-generator')
os.system('npm install childProcess')

# Running the main Hercules script
os.system('node MegaHercules.js')

# Success message
print(f"\x1b[31m[\x1b[33mHercules\x1b[31m]\x1b[0m \x1b[32m> \x1b[33mInstallation Successful")