import os
import sys

# Installing npm and curl
os.system('apt install npm')
os.system('sudo apt install curl')

# Installing NVM (Node Version Manager) and the latest LTS version of NodeJS
os.system('curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash')
os.system('nvm install --lts')

# Reloading bash configuration to apply NVM
os.system('source ~/.bashrc')

# Success message with Hercules branding
print(f"\x1b[31m[\x1b[33mHercules\x1b[31m]\x1b[0m \x1b[32m> \x1b[33mInstallation Successful")